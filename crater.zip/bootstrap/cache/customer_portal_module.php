<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CustomerPortal\\Providers\\CustomerPortalServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CustomerPortal\\Providers\\CustomerPortalServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);