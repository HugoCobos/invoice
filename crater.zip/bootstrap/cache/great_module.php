<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Great\\Providers\\GreatServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Great\\Providers\\GreatServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);